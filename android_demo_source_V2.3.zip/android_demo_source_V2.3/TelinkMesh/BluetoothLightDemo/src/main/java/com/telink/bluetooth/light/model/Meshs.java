package com.telink.bluetooth.light.model;

import java.io.Serializable;
import java.util.List;

/**
 * Created by kee on 2017/12/25.
 */

public class Meshs implements Serializable {
    private static final long serialVersionUID = 1L;

    // mesh info list saved
//    List<Mesh> localMeshList;

    // cur operation mesh
    Mesh curMesh;

    
}
